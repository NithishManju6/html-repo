"use strict";

chrome.tabs.create({
  url: "http://onthisdaytab.com/",
  active: true,
});
